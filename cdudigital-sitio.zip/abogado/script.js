document.getElementById('f').addEventListener('submit',e=>{e.preventDefault();
const t='Hola! Soy '+n.value+'. Consulta sobre '+document.getElementById('t').value+'. '+m.value;
window.open('https://wa.me/541159384727?text='+encodeURIComponent(t),'_blank')});
